import { finalize, map, Observable } from 'rxjs';

import { Component, OnInit, Optional, ViewChild } from '@angular/core';
import { ApiHttpService, CallFuncService, DialogData, DialogRef, NotificationsService } from 'codx-core';
import { dispatch } from '@modules/od/models/dispatch.model';
import { extractContent } from '@modules/od/function/default.function';
import { DispatchService } from '@modules/od/services/dispatch.service';
import { AttachmentComponent } from '@shared/components/attachment/attachment.component';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-imcomming-add',
  templateUrl: './incomming-add.component.html',
  styleUrls: ['./incomming-add.component.scss'],
})
export class IncommingAddComponent implements OnInit {
  @ViewChild('attachment') attachment: AttachmentComponent
  @ViewChild('tmpagency') tmpagency: AnalyserNode;
  data: any = {};
  dialog: any;
  activeAngecy      = 1;
  showAgency        = false;
  idAgency          : any ;
  dispatch : any;
  headerText : any;
  gridViewSetup :any;
  type: any;
  formModel : any;
  dispatchForm = new FormGroup({
    agency: new FormControl(),
    title : new FormControl()
  });
  constructor(
    private api: ApiHttpService,
    private odService: DispatchService,
    private notifySvr: NotificationsService,
    private callfunc: CallFuncService,
    @Optional() dt?: DialogData,
    @Optional() dialog?: DialogRef
  ) 
  {
    debugger;
    this.data = dt?.data;
    this.dialog = dialog;
  }
  public disEdit: any;
  ngOnInit(): void {
    this.headerText = this.data.headerText;
    this.dispatch = this.dialog.dataService.dataSelected;
    this.dispatch.status = '1';
    this.dispatch.createdOn = new Date();
    

    //this.dialog.dataService.apiSave = (t, data) = this.api.execSv<any>('TM', 'TM', 'TaskBusiness', 'TestApiBool', this.data);
   /*  this.dialog.dataService.apiUpdate = this.api.execSv<any>(
      'TM',
      'TM',
      'TaskBusiness',
      'TestApiBool',
      this.data
    ); */
    this.gridViewSetup = this.data["gridViewSetup"];
    this.headerText = this.data["headerText"];
    this.type = this.data["type"];
    this.formModel = this.data["formModel"]
  }

  fileAdded(event) { 
    console.log(event);
  }

 //Mở form thêm mới đơn vị / phòng ban
 openFormAgency(action:any) 
 {
   if(action == "agency")
   {
      this.callfunc.openForm(this.tmpagency,null,500,600);  
    /*  this.callfc.openForm(DepartmentComponent, "Thêm mới phòng ban", 500, 700, null, this.idAgency).subscribe((dialog: any) => {
       dialog.close = this.closeDept;
     }); */
   }
   else {
     /* this.callfc.openForm(AgencyComponent, "Thêm đơn vị nhận", 500, 700, null, null).subscribe((dialog: any) => {
       dialog.close = this.closeAgency;
     }); */
   }
 }

  valueChange(evt: any) {
    this.data[evt.field] = evt.data;
  }

  saveForm() {
    this.dialog.dataService.save().subscribe();
  }

  save2() {
    this.api
      .execSv<any>('TM', 'TM', 'TaskBusiness', 'TestApiAsync')
      .subscribe((res) => {
        this.dialog.dataService.add(res).subscribe();
      });
  }

  hideDept()
  {
    this.showAgency = false;
    this.idAgency = null;
  }

  changeValueDept(event: any) {
    this.dispatch.agencyID = event[0];
  }
    //Lưu văn bản
  changeValueAgencyText(event: any) {
    this.dispatch.agencyName = event.data
  }
  changeValueCategory(event: any) {
    this.dispatch.category = event
  }
  changeValueSource(event: any) {
    this.dispatch.source = event
  }
  // Số văn bản
  changeValueRefNo(event: any) {
    this.dispatch.refNo = event.data;
  }
   //Ngày văn bản
   changeValueRefDate(event: any) {
    this.dispatch.refDate = new Date()
  }
  //Số trang
  changeValuePage(event: any) {
    this.dispatch.rages = event.data.value;
  }
  changeValueCopies(event: any) {
   this.dispatch.copies = event.data.value
  }
  
  changeValueTags(event: any) {
    if(event.data.value!=undefined)
      this.dispatch.title = event.data.value
    else this.dispatch.title = event.data
  }
  changeValueUrgency(event: any) {
    this.dispatch.urgency = event
  }
  changeValueSecurity(event: any) {
    this.dispatch.security = event
  }
  //Hình thức nhận
  changeValueSendMode(event: any) {
    this.dispatch.sendMode = event
  }
  //Ngày nhận
  changeValueDispatchOn(event: any) {
    this.dispatch.dispatchOn = event.data
  }
  //Ngày đến hạn
  changeValueDeadLine(event: any) {
    this.dispatch.deadline = event.data
  }
  
  //Người chịu trách nhiệm
  changeValueOwner(event: any) {
    debugger;
    this.dispatch.owner = event.data[0]
  }
  //Nơi nhận
  changeValueBUID(event: any, component: any = null) {
    this.dispatch.deptID = event.data[0];
    if (event[0] != "" && event[0] != null) {
     /*  this.api.execSv("HR", "ERM.Business.HR", "OrganizationUnitsBusiness", "GetUserByDept", [event[0], null, null]).subscribe((item: any) => {
        if (item != null && item.length > 0) {
          this.dispatch.Owner = this.dfDis.Owner = item[0].domainUser;
          if (this.disEdit != null) this.disEdit.owner = item[0].domainUser;
        }
        else {
          if (this.disEdit != null) this.disEdit.owner = ""
          this.dispatch.Owner = this.dfDis.Owner = "";
        }
      })*/
    } 

  }
  openFormUploadFile()
  {
    // var obj = new dispatch;
    // obj.DeptID = "1";
    // this.odService.SaveAgency1(obj).subscribe(item => {
    //   console.log(item);
    // });
    this.attachment.uploadFile();
  }
   //Các hàm value change 
   changeValueAgency(event: any) 
   {
    if(event.component.itemsSelected!=null && event.component.itemsSelected.length >0)
    {
      this.dispatch.agencyID = event.component.itemsSelected[0].AgencyID;
      this.dispatch.agencyName = event.component.itemsSelected[0].AgencyName;
      if(this.dispatch.agencyID != this.dispatch.agencyName) this.showAgency = true;
    }
  }

  /////// lưu/câp nhật công văn
  onSave() {
    this.dispatch.Status = "1",
    this.dispatch.ApproveStatus = "1",
    this.dispatch.DispatchType = "1";
    //this.dispatch.Title = this.dispatchForm.value.title;
    if(this.dispatch.dispatchOn == undefined) this.dispatch.dispatchOn = new Date();
    // this.dispatch.RecID = this.dialog.dataService.dataSelected._uuid;
    //this.dialog.dataService.dataSelected = this.dispatch;
    //this.dialog.dataService.save().subscribe();
    if(this.type == "add" || this.type == "copy")
    {
      if(this.type == "copy")
      {
        this.dispatch.relations= null;
        this.dispatch.permissions = null;
        delete this.dispatch.id
      }
      
      this.odService.saveDispatch(this.dispatch).subscribe((item) => {
          if (item.status == 0) {
            //this.listview.addHandler(item.data, true, "recID");
            /* if(this.fileAdd!= undefined && this.fileAdd!= null && this.fileAdd.length >0)
            {
              this.fileAdd.forEach((elm)=>{
                this.fileService.updateFileByObjectIDType(elm.objectId,item.data.recID,"OD_Dispatches").subscribe((item)=>{
                  //console.log(item);
                })
              })
            }
            this.fileAdd = null; 
            //this.dialog.dataService.add(item,0,true).subscribe();*/
            this.attachment.saveFiles();
            this.dialog.dataService.setDataSelected(item.data);
            this.dialog.close(true);
          }
          this.notifySvr.notify(item.message); 
        })
    }
    if(this.type == "edit")
    {
      this.dispatch.dispatchOn = new Date();
      this.dispatch.refDate = new Date();
      this.odService.updateDispatch(this.dispatch , false).subscribe((item) => {
        if (item.status == 0) {
          //this.listview.addHandler(item.data, true, "recID");
          /* if(this.fileAdd!= undefined && this.fileAdd!= null && this.fileAdd.length >0)
          {
            this.fileAdd.forEach((elm)=>{
              this.fileService.updateFileByObjectIDType(elm.objectId,item.data.recID,"OD_Dispatches").subscribe((item)=>{
                //console.log(item);
              })
            })
          }
          this.fileAdd = null; 
          //this.dialog.dataService.add(item,0,true).subscribe();*/
          //this.dialog.dataService.setDataSelected(item.data);
          //this.dialog.dataService.setDataSelected(item.data);
          this.attachment.saveFiles();
          this.dialog.close(item.data);
        }
        this.notifySvr.notify(item.message); 
      })
    } 
  }
}
